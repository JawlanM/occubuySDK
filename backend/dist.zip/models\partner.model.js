"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Partner = void 0;
const mongoose_1 = require("mongoose");
const audit_schema_1 = require("../models/audit.schema");
const contactSchema = new mongoose_1.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, lowercase: true },
    phone: { type: String, required: true },
}, { _id: false });
const PartnerSchema = new mongoose_1.Schema({
    partnerId: { type: String, required: true, unique: true },
    legalName: { type: String, required: true },
    tradingName: { type: String },
    abn: { type: String, required: true },
    apiKeyPrefix: { type: String, required: true, unique: true },
    apiKeyHash: { type: String, required: true, select: false },
    category: {
        type: String,
        enum: ["mortgage", "property", "insurance", "utility", "lifestyle"],
        required: true,
    },
    status: {
        type: String,
        enum: [
            "draft",
            "pending_review",
            "approved",
            "live",
            "paused",
            "suspended",
            "archived",
        ],
        required: true,
        default: "draft",
    },
    primaryContact: { type: contactSchema, required: true },
    secondaryContacts: {
        type: [
            new mongoose_1.Schema({
                name: { type: String, required: true },
                email: { type: String, required: true, lowercase: true },
                phone: { type: String, required: true },
                role: { type: String, required: true },
            }, { _id: false }),
        ],
        default: [],
    },
    monetisation: {
        model: {
            type: String,
            enum: ["platform_fee_plus_conversion", "conversion_only", "subscription"],
        },
        platformFee: {
            amount: Number,
            currency: String,
            frequency: { type: String, enum: ["monthly", "annual"] },
        },
        conversionFee: {
            type: { type: String, enum: ["percent", "flat"] },
            value: Number,
            currency: String,
        },
        paymentMethodRef: String,
        billingFrequency: { type: String, enum: ["monthly", "annual"] },
    },
    compliance: {
        termsVersionAccepted: String,
        termsAcceptedAt: Date,
        termsAcceptedBy: String,
        supportingDocs: {
            type: [
                {
                    type: { type: String, required: true },
                    url: { type: String, required: true },
                    uploadedAt: { type: Date, required: true },
                },
            ],
            default: [],
        },
    },
    onboardingStage: { type: String },
    audit: { type: audit_schema_1.auditSchema, required: true },
});
PartnerSchema.index({ partnerId: 1 }, { unique: true });
PartnerSchema.index({ status: 1 });
PartnerSchema.index({ category: 1, status: 1 });
exports.Partner = (0, mongoose_1.model)("Partner", PartnerSchema);
//# sourceMappingURL=partner.model.js.map