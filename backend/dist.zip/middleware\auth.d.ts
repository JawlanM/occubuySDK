import { Request, Response, NextFunction } from "express";
import { IPartner } from "../models/partner.model";
declare global {
    namespace Express {
        interface Request {
            partner?: IPartner;
        }
    }
}
export declare function authenticatePartnerKey(req: Request): Promise<IPartner | null>;
export declare function requirePartnerAuth(req: Request, res: Response, next: NextFunction): Promise<void>;
export declare function verifySessionToken(scoreId: string, token: string | undefined): Promise<boolean>;
declare function sessionHeader(req: Request): string | undefined;
export declare function requireSessionAuth(req: Request, res: Response, next: NextFunction): void;
export { sessionHeader };
//# sourceMappingURL=auth.d.ts.map