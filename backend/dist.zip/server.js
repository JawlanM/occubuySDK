"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const db_1 = require("./config/db");
const app_1 = require("./app");
const PORT = process.env.PORT ?? 8787;
async function main() {
    await (0, db_1.connectDB)();
    app_1.app.listen(PORT, () => {
        console.log(`Occubuy backend listening on http://localhost:${PORT}`);
    });
}
main().catch((err) => {
    console.error("Failed to start server:", err);
    process.exit(1);
});
//# sourceMappingURL=server.js.map