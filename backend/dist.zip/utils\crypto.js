"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hashSecret = hashSecret;
exports.secretMatchesHash = secretMatchesHash;
exports.generateApiKey = generateApiKey;
exports.generateSessionToken = generateSessionToken;
const crypto_1 = require("crypto");
// never store the raw key/token, only this hash. pepper is a secret that only lives
// on the server, so even if someone gets the mongo dump they can't just brute force it
function pepper() {
    return process.env.OCCUBUY_HASH_PEPPER ?? "dev-only-pepper-change-me";
}
function hashSecret(secret) {
    return (0, crypto_1.createHash)("sha256").update(`${secret}:${pepper()}`).digest("hex");
}
// timingSafeEqual so someone can't guess the key byte by byte from response speed
function secretMatchesHash(secret, hash) {
    const candidate = Buffer.from(hashSecret(secret));
    const stored = Buffer.from(hash);
    if (candidate.length !== stored.length)
        return false;
    return (0, crypto_1.timingSafeEqual)(candidate, stored);
}
function generateApiKey(prefix) {
    const secret = (0, crypto_1.randomBytes)(24).toString("hex");
    const fullKey = `pk_sandbox_${prefix}_${secret}`;
    return { fullKey, prefix: `pk_sandbox_${prefix}`, hash: hashSecret(fullKey) };
}
function generateSessionToken() {
    const token = (0, crypto_1.randomBytes)(24).toString("hex");
    return { token, hash: hashSecret(token) };
}
//# sourceMappingURL=crypto.js.map