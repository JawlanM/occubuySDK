"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const db_1 = require("./config/db");
(0, db_1.connectDB)()
    .then(() => process.exit(0))
    .catch((err) => {
    console.error("Connection failed:", err);
    process.exit(1);
});
//# sourceMappingURL=test-connection.js.map