"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.auditSchema = void 0;
const mongoose_1 = require("mongoose");
exports.auditSchema = new mongoose_1.Schema({
    createdAt: { type: Date, required: true, default: Date.now },
    createdBy: { type: String, required: true },
    updatedAt: { type: Date, required: true, default: Date.now },
    updatedBy: { type: String, required: true },
}, { _id: false } // sub document does not need id
);
//# sourceMappingURL=audit.schema.js.map