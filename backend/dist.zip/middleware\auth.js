"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authenticatePartnerKey = authenticatePartnerKey;
exports.requirePartnerAuth = requirePartnerAuth;
exports.verifySessionToken = verifySessionToken;
exports.requireSessionAuth = requireSessionAuth;
exports.sessionHeader = sessionHeader;
const partner_model_1 = require("../models/partner.model");
const Userscore_model_1 = require("../models/Userscore.model");
const crypto_1 = require("../utils/crypto");
function extractBearer(req) {
    const header = req.headers["authorization"];
    if (!header || !header.startsWith("Bearer "))
        return null;
    return header.slice("Bearer ".length).trim();
}
// same check as requirePartnerAuth below but doesn't reject on failure, just returns null -
// need that for GET /scores/:scoreId where a bad partner key should fall through to the
// session-token check instead of dying immediately
async function authenticatePartnerKey(req) {
    const key = extractBearer(req);
    if (!key)
        return null;
    const lastUnderscore = key.lastIndexOf("_");
    const prefix = lastUnderscore === -1 ? key : key.slice(0, lastUnderscore);
    const partner = await partner_model_1.Partner.findOne({ apiKeyPrefix: prefix }).select("+apiKeyHash");
    if (!partner || !(0, crypto_1.secretMatchesHash)(key, partner.apiKeyHash))
        return null;
    return partner;
}
// checks the partner's key, basically the same idea as a stripe publishable key - fine to
// have this sitting in the partner's own page source, it just identifies who's calling,
// it doesn't unlock any specific customer's score on its own (that's the session token below)
async function requirePartnerAuth(req, res, next) {
    const partner = await authenticatePartnerKey(req);
    if (!partner) {
        res.status(401).json({ message: "Missing or invalid partner API key", code: "PARTNER_KEY_INVALID" });
        return;
    }
    req.partner = partner;
    next();
}
// checks the per-flow token (X-Occubuy-Session header) matches this exact scoreId.
// this is the part that actually stops someone with just the partner key from
// reading/sharing/declining a score that isn't theirs
async function verifySessionToken(scoreId, token) {
    if (!token)
        return false;
    const scoreDoc = await Userscore_model_1.UserScore.findById(scoreId).select("+sessionTokenHash");
    if (!scoreDoc)
        return false;
    return (0, crypto_1.secretMatchesHash)(token, scoreDoc.sessionTokenHash);
}
function sessionHeader(req) {
    const header = req.headers["x-occubuy-session"];
    return typeof header === "string" ? header : undefined;
}
function requireSessionAuth(req, res, next) {
    const { scoreId } = req.params;
    verifySessionToken(scoreId, sessionHeader(req))
        .then((ok) => {
        if (!ok) {
            res.status(401).json({ message: "Invalid or missing session token", code: "SESSION_INVALID" });
            return;
        }
        next();
    })
        .catch(next);
}
//# sourceMappingURL=auth.js.map