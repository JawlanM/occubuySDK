export interface ApplicantInput {
    fullName?: unknown;
    email?: unknown;
    phone?: unknown;
    dob?: unknown;
    address?: unknown;
}
export interface ValidatedApplicant {
    fullName: string;
    email: string;
    phone: string;
    dob: string;
    address: string;
}
export interface ValidationError {
    field: string;
    code: string;
    message: string;
}
export declare function validateApplicant(input: ApplicantInput): {
    ok: true;
    applicant: ValidatedApplicant;
} | {
    ok: false;
    errors: ValidationError[];
};
//# sourceMappingURL=validators.d.ts.map