"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectDB = connectDB;
const mongoose_1 = __importDefault(require("mongoose"));
const dotenv_1 = __importDefault(require("dotenv"));
const dns_1 = require("dns");
//dotenv reads .env
// loads variables from .env into process.env
dotenv_1.default.config();
// some ISP/router DNS resolvers don't answer Node's own SRV lookups even though the OS
// resolver handles them fine (nslookup works, node's dns.resolveSrv doesn't) - this breaks
// mongodb+srv:// connection strings specifically. pointing node at a public resolver fixes it.
(0, dns_1.setServers)(["8.8.8.8", "1.1.1.1"]);
async function connectDB() {
    const uri = process.env.MONGODB_URI;
    if (!uri) {
        throw new Error("MONGODB_URI is not set in your .env file.");
    }
    //cal to open connection
    await mongoose_1.default.connect(uri);
    console.log("MongoDB connected:", mongoose_1.default.connection.name);
}
//# sourceMappingURL=db.js.map