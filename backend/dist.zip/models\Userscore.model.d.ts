import { Document } from "mongoose";
interface ILinkedAccount {
    providerId?: number;
    providerAccountId: number;
    requestId: string;
    providerName?: string;
    additionalStatus?: string;
}
interface IScoreData {
    value: number;
    band: "Excellent" | "Good" | "Fair" | "Poor" | "Insufficient Data";
}
export interface IApplicant {
    fullName: string;
    email: string;
    phone: string;
    dob: string;
    address: string;
}
export interface IUserScore extends Document {
    userId: string;
    applicant: IApplicant;
    status: "CREATED" | "PROCESSING" | "COMPLETED" | "FAILED";
    linkedAccount?: ILinkedAccount;
    score?: IScoreData;
    sessionTokenHash: string;
    sharedAt?: Date | null;
    declinedAt?: Date | null;
    createdAt: Date;
    updatedAt: Date;
}
export declare const UserScore: import("mongoose").Model<IUserScore, {}, {}, {}, Document<unknown, {}, IUserScore, {}, import("mongoose").DefaultSchemaOptions> & IUserScore & Required<{
    _id: import("mongoose").Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IUserScore>;
export {};
//# sourceMappingURL=Userscore.model.d.ts.map