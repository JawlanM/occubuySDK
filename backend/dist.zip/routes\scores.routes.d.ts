export declare const scoresRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=scores.routes.d.ts.map