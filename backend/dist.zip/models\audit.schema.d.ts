import { Schema } from "mongoose";
export interface IAudit {
    createdAt: Date;
    createdBy: string;
    updatedAt: Date;
    updatedBy: string;
}
export declare const auditSchema: Schema<IAudit, import("mongoose").Model<IAudit, any, any, any, any, any, IAudit>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, IAudit, import("mongoose").Document<unknown, {}, IAudit, {
    id: string;
}, import("mongoose").DefaultSchemaOptions> & Omit<IAudit & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, "id"> & import("mongoose").HydratedDocumentOverrides<{
    id: string;
}>, {
    createdAt?: import("mongoose").SchemaDefinitionProperty<Date, IAudit, import("mongoose").Document<unknown, {}, IAudit, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<IAudit & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    createdBy?: import("mongoose").SchemaDefinitionProperty<string, IAudit, import("mongoose").Document<unknown, {}, IAudit, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<IAudit & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    updatedAt?: import("mongoose").SchemaDefinitionProperty<Date, IAudit, import("mongoose").Document<unknown, {}, IAudit, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<IAudit & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    updatedBy?: import("mongoose").SchemaDefinitionProperty<string, IAudit, import("mongoose").Document<unknown, {}, IAudit, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<IAudit & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
}, IAudit>;
//# sourceMappingURL=audit.schema.d.ts.map