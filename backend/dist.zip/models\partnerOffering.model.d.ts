import { Document, Types } from "mongoose";
import { IAudit } from "../models/audit.schema";
interface IEligibility {
    minDeposit?: number;
    suburbs?: string[];
    memberSegment?: string;
}
export interface IPartnerOffering extends Document {
    offeringId: string;
    partnerId: Types.ObjectId;
    title: string;
    shortDescription: string;
    longDescription?: string;
    heroImage?: string;
    gallery?: string[];
    category: "mortgage" | "property" | "insurance" | "utility" | "lifestyle";
    subCategory?: string;
    tags?: string[];
    terms?: Record<string, unknown>;
    pricingDetails?: Record<string, unknown>;
    eligibility?: IEligibility;
    displayPriority?: number;
    featuredFlag?: boolean;
    status: "draft" | "pending_review" | "live" | "paused" | "archived";
    version: number;
    audit: IAudit;
}
export declare const PartnerOffering: import("mongoose").Model<IPartnerOffering, {}, {}, {}, Document<unknown, {}, IPartnerOffering, {}, import("mongoose").DefaultSchemaOptions> & IPartnerOffering & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IPartnerOffering>;
export {};
//# sourceMappingURL=partnerOffering.model.d.ts.map