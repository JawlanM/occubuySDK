import { Document } from "mongoose";
import { IAudit } from "../models/audit.schema";
interface IContact {
    name: string;
    email: string;
    phone: string;
}
interface ISecondaryContact extends IContact {
    role: string;
}
interface IMonetisation {
    model: "platform_fee_plus_conversion" | "conversion_only" | "subscription";
    platformFee?: {
        amount: number;
        currency: string;
        frequency: "monthly" | "annual";
    };
    conversionFee?: {
        type: "percent" | "flat";
        value: number;
        currency: string;
    };
    paymentMethodRef?: string;
    billingFrequency?: "monthly" | "annual";
}
interface ICompliance {
    termsVersionAccepted?: string;
    termsAcceptedAt?: Date;
    termsAcceptedBy?: string;
    supportingDocs?: Array<{
        type: string;
        url: string;
        uploadedAt: Date;
    }>;
}
export interface IPartner extends Document {
    partnerId: string;
    legalName: string;
    tradingName?: string;
    abn: string;
    apiKeyPrefix: string;
    apiKeyHash: string;
    category: "mortgage" | "property" | "insurance" | "utility" | "lifestyle";
    status: "draft" | "pending_review" | "approved" | "live" | "paused" | "suspended" | "archived";
    primaryContact: IContact;
    secondaryContacts?: ISecondaryContact[];
    monetisation?: IMonetisation;
    compliance?: ICompliance;
    onboardingStage?: string;
    audit: IAudit;
}
export declare const Partner: import("mongoose").Model<IPartner, {}, {}, {}, Document<unknown, {}, IPartner, {}, import("mongoose").DefaultSchemaOptions> & IPartner & Required<{
    _id: import("mongoose").Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IPartner>;
export {};
//# sourceMappingURL=partner.model.d.ts.map