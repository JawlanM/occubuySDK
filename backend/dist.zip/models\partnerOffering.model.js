"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PartnerOffering = void 0;
const mongoose_1 = require("mongoose");
const audit_schema_1 = require("../models/audit.schema");
const PartnerOfferingSchema = new mongoose_1.Schema({
    offeringId: { type: String, required: true, unique: true },
    //pointer to a document in the `Partner` collection, not a copy of its data.
    partnerId: { type: mongoose_1.Schema.Types.ObjectId, ref: "Partner", required: true },
    title: { type: String, required: true },
    shortDescription: { type: String, required: true, maxlength: 200 },
    longDescription: { type: String },
    heroImage: { type: String },
    gallery: { type: [String], default: [] },
    category: {
        type: String,
        enum: ["mortgage", "property", "insurance", "utility", "lifestyle"],
        required: true,
    },
    subCategory: { type: String },
    tags: { type: [String], default: [] },
    terms: { type: mongoose_1.Schema.Types.Mixed },
    pricingDetails: { type: mongoose_1.Schema.Types.Mixed },
    eligibility: {
        minDeposit: Number,
        suburbs: { type: [String], default: [] },
        memberSegment: String,
    },
    displayPriority: { type: Number, default: 0 },
    featuredFlag: { type: Boolean, default: false },
    status: {
        type: String,
        enum: ["draft", "pending_review", "live", "paused", "archived"],
        required: true,
        default: "draft",
    },
    // Increments on each material edit 
    //  Logic doesnt exist yet, just lies in controller
    version: { type: Number, required: true, default: 1 },
    audit: { type: audit_schema_1.auditSchema, required: true },
});
PartnerOfferingSchema.index({ offeringId: 1 }, { unique: true });
PartnerOfferingSchema.index({ partnerId: 1, status: 1 });
PartnerOfferingSchema.index({ category: 1, status: 1, displayPriority: -1 });
exports.PartnerOffering = (0, mongoose_1.model)("PartnerOffering", PartnerOfferingSchema);
//# sourceMappingURL=partnerOffering.model.js.map