export declare const fastlinkRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=fastlink.routes.d.ts.map