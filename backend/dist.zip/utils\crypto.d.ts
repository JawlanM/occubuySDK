export declare function hashSecret(secret: string): string;
export declare function secretMatchesHash(secret: string, hash: string): boolean;
export declare function generateApiKey(prefix: string): {
    fullKey: string;
    prefix: string;
    hash: string;
};
export declare function generateSessionToken(): {
    token: string;
    hash: string;
};
//# sourceMappingURL=crypto.d.ts.map