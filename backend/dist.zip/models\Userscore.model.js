"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserScore = void 0;
const mongoose_1 = require("mongoose");
const UserScoreSchema = new mongoose_1.Schema({
    userId: { type: String, required: true, index: true },
    applicant: {
        fullName: { type: String, required: true },
        email: { type: String, required: true, lowercase: true },
        phone: { type: String, required: true },
        dob: { type: String, required: true },
        address: { type: String, required: true },
    },
    status: {
        type: String,
        enum: ["CREATED", "PROCESSING", "COMPLETED", "FAILED"],
        required: true,
        default: "CREATED",
    },
    sessionTokenHash: { type: String, required: true, select: false },
    sharedAt: { type: Date, default: null },
    declinedAt: { type: Date, default: null },
    //Fastlinnk success payload
    // Filled in when POST /scores/{id}/complete is called
    linkedAccount: {
        providerId: Number,
        providerAccountId: Number,
        requestId: String,
        providerName: String,
        additionalStatus: String,
    },
    //fill when mock score engine returns
    score: {
        value: { type: Number, min: 0, max: 1000 },
        band: {
            type: String,
            enum: ["Excellent", "Good", "Fair", "Poor", "Insufficient Data"],
        },
    },
}, { timestamps: true });
exports.UserScore = (0, mongoose_1.model)("UserScore", UserScoreSchema);
//# sourceMappingURL=Userscore.model.js.map