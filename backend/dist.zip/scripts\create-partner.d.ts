export {};
//# sourceMappingURL=create-partner.d.ts.map