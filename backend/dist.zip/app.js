"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
const express_1 = __importDefault(require("express"));
const scores_routes_1 = require("./routes/scores.routes");
const fastlink_routes_1 = require("./routes/fastlink.routes");
exports.app = (0, express_1.default)();
// no cors package, just doing it by hand - partner's site and this backend are different
// origins so fetch() needs these headers or the browser blocks it. same thing the old
// server.mjs was doing, just moved here now
exports.app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Occubuy-Session");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST");
    if (req.method === "OPTIONS") {
        res.sendStatus(204);
        return;
    }
    next();
});
exports.app.use(express_1.default.json());
exports.app.use("/api", scores_routes_1.scoresRouter);
exports.app.use(fastlink_routes_1.fastlinkRouter);
//# sourceMappingURL=app.js.map